import React from 'react';
import { Package, Mail, Phone, MapPin } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <Package className="h-6 w-6" />
              <span className="text-xl font-bold">PaketExpress</span>
            </div>
            <p className="text-gray-400">
              Pouzdano i brzo posredovanje pri prenosu paketa širom zemlje.
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Brzi linkovi</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-400 hover:text-white">O nama</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white">Uslovi korišćenja</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white">Politika privatnosti</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white">FAQ</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Kontakt</h3>
            <ul className="space-y-2">
              <li className="flex items-center space-x-2">
                <Phone className="h-5 w-5 text-gray-400" />
                <span className="text-gray-400">+381 11 123 456</span>
              </li>
              <li className="flex items-center space-x-2">
                <Mail className="h-5 w-5 text-gray-400" />
                <span className="text-gray-400">info@paketexpress.rs</span>
              </li>
              <li className="flex items-center space-x-2">
                <MapPin className="h-5 w-5 text-gray-400" />
                <span className="text-gray-400">Beograd, Srbija</span>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Radno vreme</h3>
            <ul className="space-y-2 text-gray-400">
              <li>Ponedeljak - Petak: 08:00 - 20:00</li>
              <li>Subota: 09:00 - 15:00</li>
              <li>Nedelja: Zatvoreno</li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} PaketExpress. Sva prava zadržana.</p>
        </div>
      </div>
    </footer>
  );
}