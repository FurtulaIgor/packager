import React from 'react';
import { Package, Clock, Shield, Banknote } from 'lucide-react';

export function Features() {
  const features = [
    {
      icon: <Package className="h-8 w-8 text-blue-600" />,
      title: 'Siguran transport',
      description: 'Vaši paketi su u sigurnim rukama proverenih vozača'
    },
    {
      icon: <Clock className="h-8 w-8 text-blue-600" />,
      title: 'Brza dostava',
      description: 'Isporuka paketa u najkraćem mogućem roku'
    },
    {
      icon: <Shield className="h-8 w-8 text-blue-600" />,
      title: 'Osiguranje',
      description: 'Svi paketi su osigurani tokom transporta'
    },
    {
      icon: <Banknote className="h-8 w-8 text-blue-600" />,
      title: 'Povoljne cene',
      description: 'Konkurentne cene i transparentni troškovi'
    }
  ];

  return (
    <section className="py-16 bg-gray-100">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">Zašto izabrati nas?</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
              <div className="mb-4">{feature.icon}</div>
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}