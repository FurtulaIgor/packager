import React from 'react';
import { Package, Menu, X } from 'lucide-react';
import { useState } from 'react';

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-blue-600 text-white">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-2">
            <Package className="h-8 w-8" />
            <span className="text-xl font-bold">PaketExpress</span>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <a href="#" className="hover:text-blue-200">Početna</a>
            <a href="#" className="hover:text-blue-200">Kako radi</a>
            <a href="#" className="hover:text-blue-200">Cenovnik</a>
            <a href="#" className="hover:text-blue-200">Kontakt</a>
          </nav>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X /> : <Menu />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden pb-4">
            <div className="flex flex-col space-y-2">
              <a href="#" className="hover:text-blue-200 py-2">Početna</a>
              <a href="#" className="hover:text-blue-200 py-2">Kako radi</a>
              <a href="#" className="hover:text-blue-200 py-2">Cenovnik</a>
              <a href="#" className="hover:text-blue-200 py-2">Kontakt</a>
            </div>
          </nav>
        )}
      </div>
    </header>
  );
}