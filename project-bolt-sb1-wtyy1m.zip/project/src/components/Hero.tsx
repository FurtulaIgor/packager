import React from 'react';
import { ArrowRight } from 'lucide-react';

export function Hero() {
  return (
    <div className="relative bg-blue-600 text-white py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            Brz i pouzdan prenos paketa širom zemlje
          </h1>
          <p className="text-xl mb-8">
            Povežite se sa vozačima koji putuju vašom rutom i pošaljite paket brzo i povoljno.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <button className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-colors flex items-center justify-center">
              Pošalji paket
              <ArrowRight className="ml-2 h-5 w-5" />
            </button>
            <button className="border-2 border-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
              Postani vozač
            </button>
          </div>
        </div>
      </div>
      <div className="absolute bottom-0 right-0 w-full h-16 bg-gradient-to-t from-gray-100 to-transparent"></div>
    </div>
  );
}